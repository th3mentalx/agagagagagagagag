#!bin/bash
cp -rfRT views dist/views
cp -rfRT public dist/public